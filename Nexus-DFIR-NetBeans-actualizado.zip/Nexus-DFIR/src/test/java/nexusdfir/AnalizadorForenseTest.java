package nexusdfir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import static org.junit.jupiter.api.Assertions.*;

class AnalizadorForenseTest {
    private static final String SHA256_ABC =
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    private static final String SHA256_VACIO =
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

    @TempDir
    Path directorio;

    private final AnalizadorForense analizador = new AnalizadorForense();

    @Test
    void calculaHashYTamanoSinCambiarContenido() throws Exception {
        Path archivo = Files.writeString(directorio.resolve("muestra.txt"), "abc");

        ArchivoAnalizado resultado = analizador.analizar(archivo);

        assertEquals(SHA256_ABC, resultado.getHash());
        assertEquals(3L, resultado.getTamano());
        assertEquals("abc", Files.readString(archivo));
    }

    @Test
    void calculaHashDeArchivoVacio() throws Exception {
        Path archivo = Files.createFile(directorio.resolve("vacio.txt"));

        ArchivoAnalizado resultado = analizador.analizar(archivo);

        assertEquals(SHA256_VACIO, resultado.getHash());
        assertEquals(0L, resultado.getTamano());
    }

    @Test
    void comparaHashesValidos() {
        assertTrue(analizador.verificar(SHA256_ABC, SHA256_ABC));
        assertTrue(analizador.verificar(SHA256_ABC, " " + SHA256_ABC.toUpperCase(Locale.ROOT) + " "));
        assertFalse(analizador.verificar(SHA256_ABC, "0".repeat(64)));
    }

    @Test
    void rechazaHashInvalido() {
        assertThrows(IllegalArgumentException.class, () -> analizador.verificar(SHA256_ABC, "abc"));
        assertThrows(IllegalArgumentException.class, () -> analizador.verificar(SHA256_ABC, "g".repeat(64)));
    }

    @Test
    void rechazaUnDirectorio() {
        assertThrows(IOException.class, () -> analizador.analizar(directorio));
    }
}
