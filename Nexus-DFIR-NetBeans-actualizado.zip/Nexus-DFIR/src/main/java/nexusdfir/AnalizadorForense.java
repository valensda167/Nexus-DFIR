package nexusdfir;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

public class AnalizadorForense {
    public ArchivoAnalizado analizar(Path archivo) throws IOException, NoSuchAlgorithmException {
        if (!Files.isRegularFile(archivo)) {
            throw new IOException("Selecciona un archivo regular.");
        }
        BasicFileAttributes antes = Files.readAttributes(archivo, BasicFileAttributes.class);
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[8192];
        int cantidad;
        try (InputStream entrada = Files.newInputStream(archivo)) {
            while ((cantidad = entrada.read(buffer)) != -1) {
                digest.update(buffer, 0, cantidad);
            }
        }
        BasicFileAttributes despues = Files.readAttributes(archivo, BasicFileAttributes.class);
        if (antes.size() != despues.size() || !antes.lastModifiedTime().equals(despues.lastModifiedTime())) {
            throw new IOException("El archivo cambió durante el análisis. Intenta nuevamente con una copia estable.");
        }
        return new ArchivoAnalizado(archivo.getFileName().toString(),
                archivo.toAbsolutePath().toString(), antes.size(),
                antes.creationTime().toString(), antes.lastModifiedTime().toString(),
                HexFormat.of().formatHex(digest.digest()));
    }

    public boolean verificar(String calculado, String esperado) {
        if (esperado == null || !esperado.trim().matches("[0-9a-fA-F]{64}")) {
            throw new IllegalArgumentException("Ingresa un SHA-256 válido de 64 caracteres hexadecimales.");
        }
        return calculado.equalsIgnoreCase(esperado.trim());
    }
}
