package nexusdfir;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.nio.file.Path;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class NexusDFIR extends JFrame {
    private final Color fondo = new Color(16, 24, 39);
    private final Color panel = new Color(28, 40, 57);
    private final Color texto = new Color(230, 239, 250);
    private final Color acento = new Color(56, 189, 248);
    private final AnalizadorForense analizador = new AnalizadorForense();
    private ArchivoAnalizado resultado;
    private final JTextArea datos = new JTextArea();
    private final JTextField hash = new JTextField();
    private final JTextField esperado = new JTextField();
    private final JLabel estado = new JLabel("Selecciona un archivo propio o autorizado.");
    private final JButton abrir = new JButton("Seleccionar archivo");
    private final JButton verificar = new JButton("Verificar SHA-256");
    private final JButton limpiar = new JButton("Limpiar");

    public NexusDFIR() {
        setTitle("Nexus DFIR | Analizador de archivos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(720, 480));
        setSize(870, 570);
        setLocationRelativeTo(null);
        JPanel contenido = new JPanel(new BorderLayout(0, 16));
        contenido.setBackground(fondo);
        contenido.setBorder(new EmptyBorder(22, 24, 22, 24));
        setContentPane(contenido);

        JPanel cabecera = new JPanel(new BorderLayout());
        cabecera.setOpaque(false);
        JLabel titulo = new JLabel("NEXUS DFIR  /  0.1");
        titulo.setForeground(acento);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 25));
        cabecera.add(titulo, BorderLayout.NORTH);
        JLabel subtitulo = new JLabel("ANÁLISIS DE ARCHIVOS  ·  INTEGRIDAD DIGITAL");
        subtitulo.setForeground(texto);
        cabecera.add(subtitulo, BorderLayout.SOUTH);
        contenido.add(cabecera, BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout(0, 12));
        centro.setOpaque(false);
        datos.setEditable(false);
        datos.setLineWrap(true);
        datos.setWrapStyleWord(true);
        datos.setBackground(panel);
        datos.setForeground(texto);
        datos.setFont(new Font("Monospaced", Font.PLAIN, 14));
        datos.setBorder(new EmptyBorder(14, 14, 14, 14));
        datos.setText("METADATOS\n\nTodavía no se ha analizado ningún archivo.");
        centro.add(new JScrollPane(datos), BorderLayout.CENTER);
        JPanel hashes = new JPanel(new GridLayout(4, 1, 0, 5));
        hashes.setOpaque(false);
        hashes.add(etiqueta("SHA-256 calculado (selecciona el texto para copiarlo)"));
        configurarCampo(hash);
        hash.setEditable(false);
        hashes.add(hash);
        hashes.add(etiqueta("SHA-256 esperado (obtenido de una fuente confiable)"));
        configurarCampo(esperado);
        hashes.add(esperado);
        centro.add(hashes, BorderLayout.SOUTH);
        contenido.add(centro, BorderLayout.CENTER);

        JPanel pie = new JPanel(new BorderLayout(0, 10));
        pie.setOpaque(false);
        JPanel botones = new JPanel(new GridLayout(1, 3, 8, 0));
        botones.setOpaque(false);
        botones.add(abrir);
        botones.add(verificar);
        botones.add(limpiar);
        pie.add(botones, BorderLayout.NORTH);
        estado.setForeground(texto);
        pie.add(estado, BorderLayout.SOUTH);
        contenido.add(pie, BorderLayout.SOUTH);
        verificar.setEnabled(false);
        abrir.addActionListener(e -> seleccionarArchivo());
        verificar.addActionListener(e -> verificarHash());
        limpiar.addActionListener(e -> limpiarDatos());
    }

    private JLabel etiqueta(String valor) {
        JLabel etiqueta = new JLabel(valor);
        etiqueta.setForeground(texto);
        return etiqueta;
    }

    private void configurarCampo(JTextField campo) {
        campo.setBackground(panel);
        campo.setForeground(texto);
        campo.setCaretColor(texto);
        campo.setFont(new Font("Monospaced", Font.PLAIN, 13));
    }

    private void seleccionarArchivo() {
        JFileChooser selector = new JFileChooser();
        if (selector.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        Path archivo = selector.getSelectedFile().toPath();
        limpiarDatos();
        abrir.setEnabled(false);
        limpiar.setEnabled(false);
        estado.setText("Analizando archivo...");
        new SwingWorker<ArchivoAnalizado, Void>() {
            @Override
            protected ArchivoAnalizado doInBackground() throws Exception {
                return analizador.analizar(archivo);
            }
            @Override
            protected void done() {
                try {
                    resultado = get();
                    datos.setText("METADATOS DEL SISTEMA DE ARCHIVOS\n\n"
                            + "Nombre: " + resultado.getNombre() + "\n"
                            + "Ruta: " + resultado.getRuta() + "\n"
                            + "Tamaño: " + resultado.getTamano() + " bytes\n"
                            + "Creación (UTC): " + resultado.getCreacion() + "\n"
                            + "Modificación (UTC): " + resultado.getModificacion());
                    datos.setCaretPosition(0);
                    hash.setText(resultado.getHash());
                    hash.setCaretPosition(0);
                    verificar.setEnabled(true);
                    estado.setText("Análisis completado. El hash identifica el contenido leído.");
                } catch (Exception e) {
                    Throwable causa = e.getCause() == null ? e : e.getCause();
                    estado.setText("No se pudo analizar el archivo.");
                    JOptionPane.showMessageDialog(NexusDFIR.this, causa.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    abrir.setEnabled(true);
                    limpiar.setEnabled(true);
                }
            }
        }.execute();
    }

    private void verificarHash() {
        if (resultado == null) return;
        try {
            boolean coincide = analizador.verificar(resultado.getHash(), esperado.getText());
            estado.setForeground(coincide ? new Color(74, 222, 128) : new Color(251, 191, 36));
            estado.setText(coincide ? "COINCIDE: mismo hash que la referencia." : "NO COINCIDE: el hash difiere de la referencia.");
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Hash inválido", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void limpiarDatos() {
        resultado = null;
        datos.setText("METADATOS\n\nTodavía no se ha analizado ningún archivo.");
        hash.setText("");
        esperado.setText("");
        estado.setForeground(texto);
        estado.setText("Selecciona un archivo propio o autorizado.");
        verificar.setEnabled(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new NexusDFIR().setVisible(true));
    }
}
