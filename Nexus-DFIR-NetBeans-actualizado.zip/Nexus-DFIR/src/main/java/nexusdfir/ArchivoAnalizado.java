package nexusdfir;

public class ArchivoAnalizado {
    private final String nombre;
    private final String ruta;
    private final long tamano;
    private final String creacion;
    private final String modificacion;
    private final String hash;

    public ArchivoAnalizado(String nombre, String ruta, long tamano,
                            String creacion, String modificacion, String hash) {
        this.nombre = nombre;
        this.ruta = ruta;
        this.tamano = tamano;
        this.creacion = creacion;
        this.modificacion = modificacion;
        this.hash = hash;
    }

    public String getNombre() { return nombre; }
    public String getRuta() { return ruta; }
    public long getTamano() { return tamano; }
    public String getCreacion() { return creacion; }
    public String getModificacion() { return modificacion; }
    public String getHash() { return hash; }
}
